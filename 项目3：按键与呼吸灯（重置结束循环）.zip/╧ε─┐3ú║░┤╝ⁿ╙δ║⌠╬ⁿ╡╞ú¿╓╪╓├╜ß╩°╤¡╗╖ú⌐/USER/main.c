#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "beep.h"
#include "key.h"

int main(void)
{
    vu8 key = 0;

    HAL_Init();                    	//��ʼ��HAL��
    Stm32_Clock_Init(RCC_PLL_MUL9); //����ʱ��,72M
    delay_init(72);                 //��ʼ����ʱ����
    LED_Init();                     //��ʼ��LED
    KEY_Init();						//��ʼ������
    BEEP_Init();					//��ʼ��BEEP
   

    while (1)
    {HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
        key = KEY_Scan(0); //�õ���ֵ

        switch (key)
        {
            case KEY0_PRES://KEY0 ���е����α����ͱ䰵��ѭ��
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
							while (1)
							{
               for(int a=0;a<501;a++)
			          {
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
									delay_us(a);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
									delay_us(1000-a);
								}
								for(int b=0;b<501;b++)
			          {
									  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
								delay_us(b+500);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
									delay_us(500-b);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
									delay_us(b);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
									delay_us(1000-b);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
								for(int c=0;c<501;c++)
			          {
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
									delay_us(c+500);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
									delay_us(500-c);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
									delay_us(c);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
									delay_us(1000-c);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
								for(int d=0;d<501;d++)
			          {
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
									delay_us(500+d);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
									delay_us(500-d);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
									delay_us(d);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
									delay_us(1000-d);
								}
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
								for(int e=0;e<501;e++)
			          {
               HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
									delay_us(500+e);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
									delay_us(500-e);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
									delay_us(e);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
									delay_us(1000-e);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
								for(int f=0;f<501;f++)
			          {
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4�� 
								delay_us(500+f);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
									delay_us(500-f);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
									delay_us(f);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
									delay_us(1000-f);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4�� 
								for(int g=0;g<501;g++)
			          {
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
									delay_us(500+g);
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
									delay_us(500-g);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
									delay_us(g);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
									delay_us(1000-g);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
								for(int h=0;h<501;h++)
			          {
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
									delay_us(500+h);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
									delay_us(500-h);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
									delay_us(h);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
									delay_us(1000-h);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
								for(int i=0;i<501;i++)
			          {
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
									delay_us(500+i);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
									delay_us(1000-i);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
								for(int j=0;j<501;j++)
			          {
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
									delay_us(1000-j);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
									delay_us(j);
								}
								for(int k=0;k<501;k++)
			          {
									  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
								delay_us(500-k);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
									delay_us(k+500);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
									delay_us(1000-k);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
									delay_us(k);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
								for(int l=0;l<501;l++)
			          {
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
									delay_us(500-l);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
									delay_us(l+500);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
									delay_us(1000-l);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
									delay_us(l);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
								for(int m=0;m<501;m++)
			          {
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
									delay_us(500-m);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
									delay_us(500+m);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
									delay_us(1000-m);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
									delay_us(m);
								}
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
								for(int n=0;n<501;n++)
			          {
               HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
									delay_us(500-n);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
									delay_us(500+n);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
									delay_us(1000-n);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
									delay_us(n);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
								for(int o=0;o<501;o++)
			          {
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4�� 
								delay_us(500-o);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
									delay_us(500+o);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
									delay_us(1000-o);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
									delay_us(o);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
								for(int p=0;p<501;p++)
			          {
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
									delay_us(500-p);
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
									delay_us(500+p);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
									delay_us(1000-p);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
									delay_us(p);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
								for(int q=0;q<501;q++)
			          {
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
									delay_us(500-q);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
									delay_us(500+q);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
									delay_us(1000-q);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
									delay_us(q);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
								for(int r=0;r<501;r++)
			          {
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
									delay_us(500-r);
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
									delay_us(500+r);
								}
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
			}
                break;

            case KEY1_PRES://KEY1 ����4��һ������ͱ䰵���������
							while (1)
							{
                 for(int b=0;b<1001;b++)
			          {
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
					     HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
					     delay_us(b);
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
					      delay_us(1000-b);
							}
								for(int c=0;c<1001;c++)
			          {
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
					     HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
					     delay_us(1000-c);
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
					      delay_us(c);
							}
						}
                break;

            case KEY2_PRES: //KEY2 ���е�һ������ͱ䰵��ѭ��
							  while (1)
    {
          for(int b=0;b<1001;b++)
			   {
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
					 delay_us(b);
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
			   delay_us(1000-b);
				 }
				 for(int c=0;c<1001;c++)
			   {
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
					 delay_us(1000-c);
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
			   delay_us(c);
				 }


    }
                
						    
                break;

            case WKUP_PRES://KEY_UP ÿ���������ƽ�������ͱ䰵��ѭ��
							while(1)
							{
								for(int b=0;b<1001;b++)
			         {
                 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
					     delay_us(b);
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
					     delay_us(1000-b);
				       }
							 for(int c=0;c<1001;c++)
			         {
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
					     delay_us(1000-c);
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
					      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
								 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
					     delay_us(c);
							}
						}
                break;

            default:
                delay_ms(10);
        }
    }
}

