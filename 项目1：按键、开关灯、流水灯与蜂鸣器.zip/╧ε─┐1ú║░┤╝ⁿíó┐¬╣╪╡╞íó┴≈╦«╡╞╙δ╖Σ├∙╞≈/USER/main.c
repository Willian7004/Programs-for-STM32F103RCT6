#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "beep.h"
#include "key.h"

int main(void)
{
    vu8 key = 0;

    HAL_Init();                    	//��ʼ��HAL��
    Stm32_Clock_Init(RCC_PLL_MUL9); //����ʱ��,72M
    delay_init(72);                 //��ʼ����ʱ����
    LED_Init();                     //��ʼ��LED
    KEY_Init();						//��ʼ������
    BEEP_Init();					//��ʼ��BEEP
   

    while (1)
    {
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
        key = KEY_Scan(0); //�õ���ֵ

        switch (key)
        {
            case KEY0_PRES://KEY0 ��ˮ�ƣ����ظ���
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
        delay_ms(125);                                  //��ʱ125ms
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
        delay_ms(125);                                   //��ʱ125ms
			  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
        delay_ms(125);                                   //��ʱ125ms
		  	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
        delay_ms(125);                                   //��ʱ125ms
			  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
        delay_ms(125);                                   //��ʱ125ms
			  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
        delay_ms(125);                                   //��ʱ125ms
			  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
        delay_ms(125);                                   //��ʱ125ms
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
        delay_ms(125);                                   //��ʱ125ms
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��

                break;

            case KEY1_PRES://KEY1 �����е�
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
                break;

            case KEY2_PRES://KEY2 �����е�
							
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
						    
                break;

            case WKUP_PRES://KEY_UP ��������һ��
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
                 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET); //BEEP�������ͣ��죬 ��ͬBEEP=0;
                delay_ms(100);
						    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET); //BEEP�������ߣ����죬��ͬBEEP=1;
                break;

            default:
                delay_ms(10);
        }
    }
}

