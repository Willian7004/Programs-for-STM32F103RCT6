#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "smg.h"
#include "remote.h"
#include "timer.h"
#include "beep.h"
int r=0;
void light()
{
	if(r>127)  //ͨ��ȡ��ת�����Ʋ�������Ӧ��LED��
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); //LED7��
						}else
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
						}
						if(r%128>63)
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //LED6��
						}else
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						}
						if(r%64>31)
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //LED5��
						}else
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
						}
						if(r%32>15)
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); //LED4��
						}else
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
						}
						if(r%16>7)
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); //LED3��
						}else
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
						}
						if(r%8>3)
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); //LED2��
						}else
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						}
						if(r%4>1)
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); //LED1��
						}else
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
						}
						if(r%2>0)
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); //LED0��
						}else
						{
							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
						}
}

// ������������
// 0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F, .��ȫ��
u8 smg_num[] = {0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e, 0x01, 0x00};
u8 key = 0; //����ֵ
u8 num = 0x00; //��ֵ
u8 num1 = 0x00; //��ֵ
u8 smg_wei = 6; //�����λѡ
u8 smg_duan = 0; //����ܶ�ѡ
u8 smg_flag = 0; //�������ʾ��־ 0:������ʾ 1:������Ӱ
u8 t = 0;
int a=0;
	int b=0;
	int c=0;
	int d=0;
	int e=0;
	int f=0;
	int g=0;
	int h=0;
	
	int i=0;
	int j=0;
	int k=0;
	int l=0;
	int m=0;
	int n=0;
	int o=0;
	int p=0;
	int s=0;
	int u=0;
	int q=0;
	
int main(void)
{

    HAL_Init();                    	//��ʼ��HAL��
    Stm32_Clock_Init(RCC_PLL_MUL9); //����ʱ��,72M
    delay_init(72);                 //��ʼ����ʱ����
    uart_init(115200);	 	        //���ڳ�ʼ��Ϊ115200
    LED_Init();		  		        //��ʼ����LED���ӵ�Ӳ���ӿ�
    BEEP_Init();                    //��������ʼ��
    LED_Init();		  		        //��ʼ����LED���ӵ�Ӳ���ӿ�
    LED_SMG_Init();                 //����ܳ�ʼ��
    TIM4_Init(19, 7199);            //�����2ms��ʱ��ʾ
    Remote_Init();			        //������ճ�ʼ��
	num1 = smg_num[0];
    while (1)
    {
    }

}


//��ʱ��4�жϷ���������
void TIM4_IRQHandler(void)
{
    if (__HAL_TIM_GET_IT_SOURCE(&TIM4_Handler, TIM_IT_UPDATE) != RESET)
    {
        __HAL_TIM_CLEAR_IT(&TIM4_Handler, TIM_IT_UPDATE);

        key = Remote_Scan();

        if (key)
        {
            switch (key)
            {
                case 104:
									a++;    //���ض�Ӧ��LED��
								if(a==2)   //ͨ��r��ֵ��¼����״̬
									a=0;
								if(a==1)
								{r=r+1;
									light();}
								if(a==0)
								{r=r-1;
									light();}
								
                    break; //����'1'

                case 152:
                    b++;
								if(b==2)
									b=0;
								if(b==1)
								{r=r+2;
									light();}
								if(b==0)
								{r=r-2;
									light();}
								
                    break;     //����'2'

                case 176:
                    c++;
								if(c==2)
									c=0;
								if(c==1)
								{r=r+4;
									light();}
								if(c==0)
								{r=r-4;
									light();}
								
                    break;     //����'3'

                case 48:
                    d++;
								if(d==2)
									d=0;
								if(d==1)
								{r=r+8;
									light();}
								if(d==0)
								{r=r-8;
									light();}
								
                    break;      //����'4'

                case 24:
                    e++;
								if(e==2)
									e=0;
								if(e==1)
								{r=r+16;
									light();}
								if(e==0)
								{r=r-16;
									light();}
								
                    break;      //����'5'

                case 122:
                    f++;
								if(f==2)
									f=0;
								if(f==1)
								{r=r+32;
									light();}
								if(f==0)
								{r=r-32;
									light();}
								
                    break;     //����'6'

                case 16:
                    g++;
								if(g==2)
									g=0;
								if(g==1)
								{r=r+64;
									light();}
								if(g==0)
								{r=r-64;
									light();}
								
                    break;      //����'7'

                case 56:
                    h++;
								if(h==2)
									h=0;
								if(h==1)
								{r=r+128;
									light();}
								if(h==0)
								{r=r-128;
									light();}
								
                    break;      //����'8'

                case 90:
                    q++;  //�ı�q��ֵ����ʾ
								if(q==2)
									q=0;
								if(q==1)
								num1 = smg_num[1];
                if(q==0)
                num1 = smg_num[0];
                    break;      //����'9'

                case 66:
									num = smg_num[0];  //q=0ʱ����ȡ�������棬q=1ʱ����ȡ������ȡ
								if(q==0)
									u=r;
								if(q==1)
								{r=u;
								light();}
                 break;      //����'0'

                case 82:
									a=0;   //�ر����е�
								b=0;
								c=0;
								d=0;
								e=0;
								f=0;
								g=0;
								h=0;
								r=0;								
								light();
                num = smg_num[17];
								
                    break;     //����'DELETE'

                case 162:
									num = smg_num[1];
								if(q==0)
									i=r;
								if(q==1)
								{r=i;
								light();}
                    break;//����'POWER'

                case 98:
									num = smg_num[2];
								if(q==0)
									j=r;
								if(q==1)
								{r=j;
								light();}
                    break;//����'UP'

                case 226:
									num = smg_num[3];
								if(q==0)
									k=r;
								if(q==1)
								{r=k;
								light();}
                    break;//����'ALIENTEK'

                case 34:
									num = smg_num[4];
								if(q==0)
									l=r;
								if(q==1)
								{r=l;
								light();}
                    break;//����'LEFT'

                case 2:
                num = smg_num[5];
								if(q==0)
									m=r;
								if(q==1)
								{r=m;
								light();}
								  break;//����'PLAY'

                case 194:
									num = smg_num[6];
								if(q==0)
									n=r;
								if(q==1)
								{r=n;
								light();}
                 break;//����'RIGHT'

                case 224:
								num = smg_num[7];
								if(q==0)
									o=r;
								if(q==1)
								{r=o;
								light();}
                    break;//����'VOL-'

                case 168:
									num = smg_num[8];
								if(q==0)
									p=r;
								if(q==1)
								{r=p;
								light();}
                    break;//����'DOWN'

                case 144:
									num = smg_num[9];
								if(q==0)
									s=r;
								if(q==1)
								{r=s;
								light();} 
                    break;//����'VOL+'
            }
        }
        
        if (smg_wei == 6) //�����λ
        {
            smg_duan = num1;
        }
        else if (smg_wei == 7)
        {
            smg_duan = num;
        }

        if (smg_flag) LED_Write_Data(0x00, smg_wei); //������Ӱ(���벻��ʾ)
        else 	  LED_Write_Data(smg_duan, smg_wei); //������ʾ

        LED_Refresh();//��������ݸ���
        smg_flag = !smg_flag;

        if (smg_flag == 0) //������ʾ�Ÿ���λ��
        {
            smg_wei++;

            if (smg_wei == 8) smg_wei = 6;
        }

        t++;

        if (t == 250) //LED0ÿ500MS��˸
        {
            t = 0;
            
        }
    }
}

