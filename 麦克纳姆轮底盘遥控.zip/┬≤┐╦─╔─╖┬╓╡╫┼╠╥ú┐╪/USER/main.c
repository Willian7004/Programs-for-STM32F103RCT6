#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "smg.h"
#include "remote.h"
#include "timer.h"
#include "beep.h"

// ������������
// 0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F, .��ȫ��
u8 smg_num[] = {0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e, 0x01, 0x00};
u8 key = 0; //����ֵ
u8 num = 0x00; //��ֵ
u8 num1 = 0x00; //��ֵ
u8 smg_wei = 6; //�����λѡ
u8 smg_duan = 0; //����ܶ�ѡ
u8 smg_flag = 0; //�������ʾ��־ 0:������ʾ 1:������Ӱ
u8 t = 0;
int a=0;
	int b=0;
	int c=0;
	int d=0;
	int e=0;
	int f=0;
	int g=0;
	int h=0;
//���ߣ�PA0��3�ֱ�ӵ�һ��L298N��IN1��IN4��PA4��7�ֱ�ӵڶ���L298N��IN4��IN1����һ��L298N��IN1��IN3���Ƶ����ת���ڶ����෴	
void wheel()  //�������ת���ƣ���ת��ǰ����ת���
{              //1����ת 2����ת�� 0��ֹͣ
	if(a==1)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);}
	if(a==0)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);}
	if(a==2)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);}
	
	if(b==1)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET);
   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);}
	if(b==0)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);}
	if(b==2)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET);}
	
	if(c==1)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET);
   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);}
	if(c==0)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);}
	if(c==2)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);}
	
	if(d==1)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET);
   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);}
	if(d==0)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);}
	if(d==2)
	{HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET);}
}

int main(void)
{

    HAL_Init();                    	//��ʼ��HAL��
    Stm32_Clock_Init(RCC_PLL_MUL9); //����ʱ��,72M
    delay_init(72);                 //��ʼ����ʱ����
    uart_init(115200);	 	        //���ڳ�ʼ��Ϊ115200
    LED_Init();		  		        //��ʼ����LED���ӵ�Ӳ���ӿ�
    BEEP_Init();                    //��������ʼ��
    LED_Init();		  		        //��ʼ����LED���ӵ�Ӳ���ӿ�
    LED_SMG_Init();                 //����ܳ�ʼ��
    TIM4_Init(19, 7199);            //�����2ms��ʱ��ʾ
    Remote_Init();			        //������ճ�ʼ��
HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
	
    while (1)
    {
    }

}


//��ʱ��4�жϷ���������
void TIM4_IRQHandler(void)
{
    if (__HAL_TIM_GET_IT_SOURCE(&TIM4_Handler, TIM_IT_UPDATE) != RESET)
    {
        __HAL_TIM_CLEAR_IT(&TIM4_Handler, TIM_IT_UPDATE);

        key = Remote_Scan();

        if (key)
        {
            switch (key)
            {
                case 104:
									num = smg_num[1];
								a=1;
								b=2;
								c=1;
								d=1;
								wheel();
                    break; //����'1'

                case 152:
                  num = smg_num[2];  
								a=1;
								b=1;
								c=1;
								d=1;
								wheel();
                    break;     //����'2'

                case 176:
                 num = smg_num[3];   
								a=2;
								b=1;
								c=1;
								d=1;
								wheel();
                    break;     //����'3'

                case 48:
                 num = smg_num[4];   
								a=1;
								b=2;
								c=2;
								d=1;
								wheel();
                    break;      //����'4'

                case 24:
                 num = smg_num[17];  
								a=0;
								b=0;
								c=0;
								d=0;
								wheel();
                    break;      //����'5'

                case 122:
                  num = smg_num[5]; 
								a=2;
								b=1;
								c=1;
								d=2;
								wheel();
                    break;     //����'6'

                case 16:
                 num = smg_num[6];   
								a=1;
								b=2;
								c=2;
								d=2;
								wheel();
                    break;      //����'7'

                case 56:
                 num = smg_num[7];   
								a=2;
								b=2;
								c=2;
								d=2;
								wheel();
                    break;      //����'8'

                case 90:
                 num = smg_num[8];   
								a=2;
								b=1;
								c=2;
								d=2;
								wheel();
                    break;      //����'9'

                case 66:
									num = smg_num[9];
								a=2;
								b=1;
								c=2;
								d=1;
								wheel();
                    break;      //����'0'

                case 82:
									num = smg_num[0];
								a=1;
								b=2;
								c=1;
								d=2;
								wheel();
                    break;     //����'DELETE'

                case 162:
									a=1;								
								wheel();
                    break;//����'POWER'

                case 98:
									a=2;								
								wheel();
                    break;//����'UP'

                case 226:									
								b=1;								
								wheel();
                    break;//����'ALIENTEK'

                case 34:									
								b=2;								
								wheel();
                    break;//����'LEFT'

                case 2:
                num = smg_num[17];
								a=0;
								b=0;
								c=0;
								d=0;
								wheel();
								   break;//����'PLAY'

                case 194:									
								c=1;
								wheel();
                    break;//����'RIGHT'

                case 224:
								c=2;
								wheel();
                    break;//����'VOL-'

                case 168:
								d=1;
								wheel();
                    break;//����'DOWN'

                case 144:
								d=2;
								wheel();
                    break;//����'VOL+'
            }
        }
        
        if (smg_wei == 6) //�����λ
        {
            smg_duan = num1;
        }
        else if (smg_wei == 7)
        {
            smg_duan = num;
        }

        if (smg_flag) LED_Write_Data(0x00, smg_wei); //������Ӱ(���벻��ʾ)
        else 	  LED_Write_Data(smg_duan, smg_wei); //������ʾ

        LED_Refresh();//��������ݸ���
        smg_flag = !smg_flag;

        if (smg_flag == 0) //������ʾ�Ÿ���λ��
        {
            smg_wei++;

            if (smg_wei == 8) smg_wei = 6;
        }

        t++;

        if (t == 250) //LED0ÿ500MS��˸
        {
            t = 0;
            
        }
    }
}

