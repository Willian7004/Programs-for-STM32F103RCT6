#include "led.h"
#include "delay.h"
#include "sys.h"
#include "includes.h"
#include "key.h"
#include "usart.h"
#include "malloc.h"
#include "smg.h"
#include "rtc.h"
#include "remote.h"
#include "beep.h"
#include "adc.h"
#include "24cxx.h"
#include "norflash.h"
#include "mass_mal.h"
#include "hw_config.h"
#include "memory.h"
#include "timer.h"
int a=0;
int h=0;
int m=0;
int s=0;
/////////////////////////UCOSII��������///////////////////////////////////
//START ����
//�����������ȼ�
#define START_TASK_PRIO      			10 //��ʼ��������ȼ�����Ϊ���
//���������ջ��С
#define START_STK_SIZE  				64
//�����ջ
OS_STK START_TASK_STK[START_STK_SIZE];
//������
void start_task(void *pdata);

//ADC����
//�����������ȼ�
#define ADC_TASK_PRIO       			7
//���������ջ��С
#define ADC_STK_SIZE  		    		64
//�����ջ
OS_STK ADC_TASK_STK[ADC_STK_SIZE];
//������
void adc_task(void *pdata);

//ң�ؿ�������
//�����������ȼ�
#define REMOTE_TASK_PRIO    			6
//���������ջ��С
#define REMOTE_STK_SIZE  		 		64
//�����ջ
OS_STK REMOTE_TASK_STK[REMOTE_STK_SIZE];
//������
void remote_task(void *pdata);

//��ˮ������
//�����������ȼ�
#define LEDS_TASK_PRIO       		 	5
//���������ջ��С
#define LEDS_STK_SIZE  				    64
//�����ջ
OS_STK LEDS_TASK_STK[LEDS_STK_SIZE];
//������
void leds_task(void *pdata);

//������
//�����������ȼ�
#define MAIN_TASK_PRIO       			4
//���������ջ��С
#define MAIN_STK_SIZE  					128
//�����ջ
OS_STK MAIN_TASK_STK[MAIN_STK_SIZE];
//������
void main_task(void *pdata);




//����ɨ������
//�����������ȼ�
#define KEY_TASK_PRIO       			2
//���������ջ��С
#define KEY_STK_SIZE  					64
//�����ջ
OS_STK KEY_TASK_STK[KEY_STK_SIZE];
//������
void key_task(void *pdata);
//////////////////////////////////////////////////////////////////////////////

OS_EVENT *msg_key;			//���������¼���

u8 key_event = 0; //�����¼� 1:��ˮ�� 2:RTCʱ�� 3:����ң�� 4:ADC�ɼ� 5:USB�¼�

//������������
//0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F, .,ȫ��
u8 smg_num[] = {0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e, 0x01, 0x00};
u8 smg_duan = 0; //����ܶ�ѡ
u8 smg_wei = 0; //�����λѡ

//ң�ذ���
u8 remote_key = 0;
u8 num1 = 0;
u8 num = 0;

//ADC��ѹ����
u16 adcx = 0;
u16 adcx1 = 0;
float temp = 0;


//ÿ2msִ��һ��,����ɨ����ʾ��
void TIM2_IRQHandler(void)//TIM2�ж�
{
    static u16 led_t = 0;

    if (__HAL_TIM_GET_IT_SOURCE(&TIM2_Handler, TIM_IT_UPDATE) != RESET) //���ָ����TIM�жϷ������:TIM2�ж�Դ
    {
        __HAL_TIM_CLEAR_IT(&TIM2_Handler, TIM_IT_UPDATE);//���TIMx���жϴ�����λ:TIM2�ж�Դ

               }
if (++led_t == 50) //��ʱ
        {
            led_t = 0;
          a++;
          if(a==10)
					{a=0;}		
					
if(a==0)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
}
if(a==1)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(a==2)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(a==3)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(a==4)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(a==5)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(a==6)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(a==7)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(a==8)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); 
}
if(a==9)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); 
}


        if (key_event == 2) //��ʾʱ�䣨ʱ���֡����λ���ڸ������Ա������������й̶�ʱ�䣩
        {if(a==0)
					{s++;}
					if(s==60)
					{s=0;
					m++;}
					if(m==60)
					{m=0;
					h++;}
					if(h==100)
					{h=0;}
            switch (smg_wei)
            {
                case 0:
                    smg_duan = smg_num[h / 10];
                    break; //ʱ

                case 1:
                    smg_duan = smg_num[h % 10];
                    break;

                case 2:
                case 5:
                    smg_duan = 0x02;
                    break;

                case 3:
                    smg_duan = smg_num[m / 10];
                    break; //��

                case 4:
                    smg_duan = smg_num[m % 10];
                    break;

                case 6:
                    smg_duan = smg_num[s / 10];
                    break; //��

                case 7:
                    smg_duan = smg_num[s % 10];
                    break;
            }
						
        }
        else if (key_event == 3) //����
        {
					a=0;
					h=0;
					m=0;
					s=0;
        }
               
        else if (key_event == 4) //��¼ʱ�䣨ʱ���֡��룩
        {
						
					int aa=a;
					int hh=h;
					int mm=m;
					int ss=s;
            switch (smg_wei)
            {
                case 0:
                    smg_duan = smg_num[hh / 10];
                    break; //ʱ

                case 1:
                    smg_duan = smg_num[hh % 10];
                    break;

                case 2:
                case 5:
                    smg_duan = 0x02;
                    break;

                case 3:
                    smg_duan = smg_num[mm / 10];
                    break; //��

                case 4:
                    smg_duan = smg_num[mm % 10];
                    break;

                case 6:
                    smg_duan = smg_num[ss / 10];
                    break; //��

                case 7:
                    smg_duan = smg_num[ss % 10];
                    break;
            }
						if(aa==0)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); //LED0��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); //LED1��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); //LED2��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); //LED3��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); //LED4��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //LED5��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //LED6��
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); //LED7��
}
if(aa==1)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(aa==2)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(aa==3)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(aa==4)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(aa==5)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(aa==6)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(aa==7)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); 
}
if(aa==8)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); 
}
if(aa==9)
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); 
						    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET); 
}

        }

        if ((key_event > 1) && (key_event < 5))
        {
            LED_Write_Data(smg_duan, smg_wei); //�������ʾ
            LED_Refresh();//ˢ����ʾ

            smg_wei++;

            if (key_event == 3)
            {
                if (smg_wei == 4) smg_wei = 6;
            }

            if (smg_wei > 7) smg_wei = 0;

        }

    }

}

//��ʼ����
void start_task(void *pdata)
{
    OS_CPU_SR cpu_sr = 0;
    pdata = pdata;
    msg_key = OSMboxCreate((void *)0);	//������Ϣ����(����)

    OSStatInit();					//��ʼ��ͳ������.�������ʱ1��������
    OS_ENTER_CRITICAL();			//�����ٽ���(�޷����жϴ��)
    
    OSTaskCreate(adc_task, (void *)0, (OS_STK *)&ADC_TASK_STK[ADC_STK_SIZE - 1], ADC_TASK_PRIO); //ADC��ѹ�ɼ�
    OSTaskCreate(leds_task, (void *)0, (OS_STK *)&LEDS_TASK_STK[LEDS_STK_SIZE - 1], LEDS_TASK_PRIO); //��ˮLED��ʾ
    OSTaskCreate(key_task, (void *)0, (OS_STK *)&KEY_TASK_STK[KEY_STK_SIZE - 1], KEY_TASK_PRIO); //��������
    OSTaskCreate(remote_task, (void *)0, (OS_STK *)&REMOTE_TASK_STK[REMOTE_STK_SIZE - 1], REMOTE_TASK_PRIO); //ң�ؿ���
    OSTaskCreate(main_task, (void *)0, (OS_STK *)&MAIN_TASK_STK[MAIN_STK_SIZE - 1], MAIN_TASK_PRIO); //��Ϣ����������
    OSTaskSuspend(START_TASK_PRIO);	//������ʼ����.
    OS_EXIT_CRITICAL();				//�˳��ٽ���(���Ա��жϴ��)
}

//ADC�������
void adc_task(void *pdata)
{
    while (1)
    {
        if (key_event == 4)
        {
            adcx = Get_Adc_Average(ADC_CHANNEL_9, 10); //ADCԭʼֵ
            temp = (float)adcx * (3.3 / 4096); //ADC��ѹֵ
            adcx1 = temp;
            temp -= adcx1;
            temp *= 1000;
        }

        delay_ms(100);
    }
}
#define swap16(x) (x&0XFF)<<8|(x&0XFF00)>>8	//�ߵ��ֽڽ����궨��
#define led_time 70  //�ӳ�ʱ�� (��λ:ms)
//ͨ��ѭ���̶�LED��ƽ�Լ�¼ʱ��(��������
void leds_task(void *pdata)
{
    
    while (1)
    {
        if (key_event == 1)
        {					
					
        }

        delay_ms(15);
    }
}

//ң��������
void remote_task(void *pdata)
{
    while (1)
    {
        if (key_event == 3)
        {
            remote_key = Remote_Scan();
        }

        delay_ms(10);
    }
}


//������
void main_task(void *pdata)
{
    u32 key = 0;
    u8 err;
    u8 i = 0;
    u8 oldkey = 1;

    __HAL_TIM_ENABLE(&TIM2_Handler);//ʹ��TIM2����

    key = KEY1_PRES;
    OSMboxPost(msg_key, (void *)key); //������Ϣ

    while (1)
    {
        key = (u32)OSMboxPend(msg_key, 10, &err);

        if (key) BEEP = 1; //�رշ�����

        switch (key)
        {
            case KEY0_PRES://LED����ʾ
                if (oldkey != key)
                {
                    oldkey = KEY0_PRES;
                    key_event = KEY0_PRES;
                    OSTaskSuspend(ADC_TASK_PRIO);	//����ADC����.
                    OSTaskSuspend(REMOTE_TASK_PRIO);	//����ң������.
                    __HAL_TIM_DISABLE(&TIM2_Handler);//�ر�������ʱ��2(�������ʾ)

                    for (i = 0; i < 8; i++)
                    {
                        LED_Write_Data(0x00, i); //�������ʾ
                        LED_Refresh();//ˢ����ʾ
                    }

                    OSTaskResume(LEDS_TASK_PRIO);//�ָ���ˮ��LED����
                }

                break;

            case KEY1_PRES://����RTCʱ����ʾ
                if (oldkey != key)
                {
                    oldkey = KEY1_PRES;
                    key_event = KEY1_PRES;
                    OSTaskSuspend(ADC_TASK_PRIO);	//����ADC����.
                    OSTaskSuspend(REMOTE_TASK_PRIO);//����ң����������.
                    __HAL_TIM_DISABLE(&TIM3_Handler);//�رն�ʱ��3(ң�������)
                    smg_duan = 0x00;
                    smg_wei = 0;
                    OSTaskSuspend(LEDS_TASK_PRIO);	//������ˮLED����.
                    HAL_GPIO_WritePin(GPIOC, 0xff, GPIO_PIN_SET); //�ر���ˮ��
                    __HAL_TIM_ENABLE(&TIM2_Handler);//������ʱ��2(�������ʾ)

                }

                break;

            case KEY2_PRES://����ң��������
                if (oldkey != key)
                {
                    oldkey = KEY2_PRES;
                    key_event = KEY2_PRES;
                    OSTaskSuspend(ADC_TASK_PRIO);//����ADC����.
                    OSTaskSuspend(LEDS_TASK_PRIO);//������ˮLED����.
                    HAL_GPIO_WritePin(GPIOC, 0xff, GPIO_PIN_SET); //�ر���ˮ��
                    __HAL_TIM_ENABLE(&TIM2_Handler);//������ʱ��2(�������ʾ)
                    num1 = 0x00;
                    num = 0x00;
                    smg_wei = 0;
                    __HAL_TIM_ENABLE(&TIM3_Handler);//ʹ�ܶ�ʱ��3(ң�������)
                    OSTaskResume(REMOTE_TASK_PRIO);//�ָ�ң��������
                }

                break;

            case WKUP_PRES://����ADC�ɼ�
                if (oldkey != key)
                {
                    oldkey = WKUP_PRES;
                    key_event = WKUP_PRES;
                    OSTaskSuspend(REMOTE_TASK_PRIO);//����ң����������.
                    __HAL_TIM_DISABLE(&TIM3_Handler);//�رն�ʱ��3(ң�������)
                    smg_duan = 0x00;
                    smg_wei = 0;
                    OSTaskSuspend(LEDS_TASK_PRIO);//������ˮLED����.
                    HAL_GPIO_WritePin(GPIOC, 0xff, GPIO_PIN_SET); //�ر���ˮ��
                    OSTaskResume(ADC_TASK_PRIO);//�ָ�ADC����
                    __HAL_TIM_ENABLE(&TIM2_Handler);//������ʱ��2(�������ʾ)
                }

                break;
        }


        delay_ms(10);
    }
}

//����ɨ������
void key_task(void *pdata)
{
    u8 key;

    while (1)
    {
        key = KEY_Scan(0);

        if (key) OSMboxPost(msg_key, (void *)key); //������Ϣ

        delay_ms(5);
    }
}

//ϵͳ��ʼ��
void system_init(void)
{
    u8 error = 0;
    HAL_Init();                    //��ʼ��HAL��
    Stm32_Clock_Init(RCC_PLL_MUL9); //����ʱ��,72M
    delay_init(72);                 //��ʼ����ʱ����
    uart_init(115200);              //���ڳ�ʼ��115200
    LED_Init();		  	    //��ʼ����LED���ӵ�Ӳ���ӿ�
    KEY_Init();				//������ʼ��
    BEEP_Init();            //��������ʼ��
    mem_init();				//��ʼ���ڴ��
    LED_SMG_Init();         //����ܳ�ʼ��
    Remote_Init();          //����ң�س�ʼ��
    Adc_Init();		  		//ADC��ʼ��
    TIM2_Init(19, 7199);    //2ms��ʱ��ʾ
    printf("ALIENTEK NANO STM32F1 V1\r\n");
    printf("Copyright(C) 2018-2028\r\n");
    printf("HARDWARE: V2.00 ,SOFTWARE: V1.00\r\n");
    printf("CPU:STM32F103RBT6 72Mhz\r\n");
    printf("FLASH:128KB  SRAM:20KB\r\n");
    Norflash_Init();       //SPI��ʼ��

   

    printf("RTC Check...\r\n");

    if (RTC_Init())        //RTCʱ�ӳ�ʼ��
    {
        printf("RTC Error!\r\n");
        LED6 = 0; //��ʾRTC����
        error = 1;
    }
    else
    {
        printf("OK\r\n");
    }

    AT24CXX_Init();        //IIC��ʼ��
    printf("24C02 Check...\r\n");

    if (AT24CXX_Check())
    {
        printf("24C02 Error!\r\n");
        LED7 = 0; //��ʾ24C02����
        error = 1;
    }
    else
    {
        printf("OK\r\n");
    }

    
    }




//������
int main(void)
{
    system_init();          //ϵͳ��ʼ��
    OSInit();  	 			//��ʼ��UCOSII
    OSTaskCreate(start_task, (void *)0, (OS_STK *)&START_TASK_STK[START_STK_SIZE - 1], START_TASK_PRIO ); //������ʼ����
    OSStart();	            //OS����


}

